

def first_fit(items: list[float], assignment: list[int], free_space: list[float]):